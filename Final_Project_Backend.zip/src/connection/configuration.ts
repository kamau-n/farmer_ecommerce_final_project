import { DataSource } from "typeorm";
import { Login } from "../models/login.model";
import { Product } from "../models/product.model";
import { Image } from "../models/images.model";
import { Messages } from "../models/messages.model";
import { ChatRoom } from "../models/room.model";
import { Complaints } from "../models/complaints.model";
import { Promoted } from "../models/promoted.model";
import { Payments } from "../models/payments.model";
import { Promotion_packages } from "../models/adpackage.model";


export const appDataSource = new DataSource({
    type: "mysql",
    database: "Farmers_Ecommerce",
    username: "root",
    password: "",
    //logging: true,
    synchronize: true,
    entities: [Login, Product, Image, Messages, ChatRoom, Complaints, Promoted, Payments, Promotion_packages]



})